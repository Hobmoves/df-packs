#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>

// Gearathon: vanilla's blocky stars are off. core/sky.fsh paints finer ones that turn with the sun.

layout(location = 0) out vec4 fragColor;

void main() {
    fragColor = ColorModulator;
    discard;
}
