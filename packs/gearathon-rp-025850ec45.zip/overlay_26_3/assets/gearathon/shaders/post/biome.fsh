#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Gearathon biome look, one post effect for the whole plot (DF: player_action.SetPostEffects gearathon:biome).
// The camera's world position (Globals.CameraBlockPos - CameraOffset) picks blended biome weights from
// textures/effect/biomes.png (3 blocks of 256x256, rows = plot z, cols = plot x):
//   block 0: R mesa, G frost, B volcanic    block 1: R blight, G forest, B smoothed ground height (y - 40)
//   block 2: R wetness (near ponds)
// and textures/effect/height.png (1024 x 1024, pixel (plot x, plot z) R = exact terrain height y - 40, no trees or
// rocks), so surface effects can tell the real ground from things standing on it.
// The probe (core/item.vsh, an item display DF keeps on each player) writes the camera rotation, projection, sky
// light and a marker into a 16 x 1 pixel strip in the bottom-left corner of main; with them every pixel gets its world position:
//   ground fog  analytic height fog per ray segment, hugging the smoothed ground, drifting with the wind:
//               blight heavy purple-grey, forest mist over ponds / wet hollows, frost blowing snow drift,
//               crags low smoke; the mesa has no dust layer here (it floated over the terraces): its dust is
//               sand streaks on the real ground only (below) plus the DF dust particles
//   wind        world-anchored snow streaks and gust sheets (frost) blowing along WIND, so they stay put when you turn
//   night       fog and haze follow DF's night steps, read from the fog colour (not the lightmap: the player's
//               brightness setting lifts that)
// Without probe data (e.g. third person) the ground fog / streaks are skipped and the rest still works.
//   mesa      light heat shimmer on distant things, warm dusty grade
//   frost     cold grade, pale haze, frosted vignette
//   volcanic  smoky brown haze, warm contrast, lava glow (bloom from post/hot)
//   blight    purple haze, desaturated, breathing vignette, grain (lighter than v1)

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D HotSampler;
uniform sampler2D BiomesSampler;
uniform sampler2D HeightSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec2 ORIGIN = vec2(0.0, 8000.0);   // world x/z of plot block (0, 0)
const float PLOT = 1001.0;
const vec2 WIND = vec2(-0.932, 0.362);    // blowing toward -x, +z (same as the DF snow particles)

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float hash3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }

float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

float fbm(vec2 p) { return 0.62 * vnoise(p) + 0.38 * vnoise(p * 2.3 + 5.2); }

// screen-space blowing snow (fallback when there is no probe data)
float snowS(vec2 px, float t, float k) {
    vec2 q = px / vec2(90.0 + 40.0 * k, 9.0 + 4.0 * k);
    q.x += t * (5.0 + 3.0 * k) + q.y * 0.35;
    q.y += t * (0.6 + 0.3 * k);
    vec2 cl = floor(q), f = fract(q);
    if (hash(cl + 17.0 * k) > 0.22) return 0.0;
    float y0 = 0.25 + 0.5 * hash(cl + 3.1), len = 0.25 + 0.5 * hash(cl + 7.7), x0 = hash(cl + 9.3) * (1.0 - len);
    return smoothstep(x0, x0 + 0.05, f.x) * smoothstep(x0 + len, x0 + len - 0.15, f.x) * (1.0 - smoothstep(0.0, 0.09, abs(f.y - y0)));
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec2 plotUV(vec2 xz) { return clamp((xz - ORIGIN + 0.5) / PLOT, 0.5 / 256.0, 1.0 - 0.5 / 256.0); }
vec3 bio(vec2 xz, float block) { vec2 p = plotUV(xz); return texture(BiomesSampler, vec2((block + p.x) / 3.0, p.y)).rgb; }

// border fog colour of a spot: each biome's misty tone, blended by the biome weights there
vec3 borderColor(vec2 xz) {
    vec3 a = bio(xz, 0.0), b = bio(xz, 1.0);              // a: mesa, frost, volcanic   b: blight, forest
    vec3 c = a.r * vec3(0.86, 0.77, 0.64) + a.g * vec3(0.88, 0.92, 0.97) + a.b * vec3(0.44, 0.38, 0.35)
           + b.r * vec3(0.56, 0.49, 0.64) + b.g * vec3(0.78, 0.86, 0.95);
    return c / max(a.r + a.g + a.b + b.r + b.g, 1e-3);
}
// Plot border fog has two looks, one switch, because the owners want different things (2026-11-08):
//   BORDER_WALL 1  Hobmoves: a towering wall that hides everything past the edge (wallTau). 18 blocks deep, density
//                  WALL_RHO * exp(-e / WALL_LAMBDA) at e blocks in, WALL_RHO past the edge, thinning toward y WALL_TOP
//                  and beyond 220-320 blocks along the ray. Opacity in 12 flat bands (no dither: 3fod disliked it),
//                  shown only within ~96 blocks of an edge.
//   BORDER_WALL 0  3fod: the low bank on the ground (borderTau below), smooth.
#define BORDER_WALL 1
const float WALL_IN = 18.0, WALL_RHO = 0.75, WALL_LAMBDA = 5.0, WALL_TOP = 300.0;
float wallTau(float e0, float de, float L, float y0, float dy, out float tAt) {
    tAt = 0.0;
    float t0 = 0.0, t1 = L;
    if (abs(de) < 1e-5) { if (e0 >= WALL_IN) return 0.0; }
    else if (de > 0.0) t1 = min(L, (WALL_IN - e0) / de);
    else t0 = max(0.0, (WALL_IN - e0) / de);
    if (t1 <= t0) return 0.0;
    float s = 0.0, st = 0.0, dt = (t1 - t0) / 8.0;
    for (int i = 0; i < 8; i++) {
        float tm = t0 + (float(i) + 0.5) * dt;
        float k = exp(-max(e0 + de * tm, 0.0) / WALL_LAMBDA) * (1.0 - smoothstep(WALL_TOP - 60.0, WALL_TOP, y0 + dy * tm))
                * (1.0 - smoothstep(220.0, 320.0, tm));
        s += k;
        st += k * tm;
    }
    tAt = st / max(s, 1e-6);
    return WALL_RHO * s * dt;
}

// plot border fog (3fod, 2026-11-08: "gradually go into the world for a few blocks and not go all the way up, max height
// 8-10 blocks"): a low bank lying on the ground along each plot edge. Density at a point along a ray =
//   BORDER_RHO * (1 - e / BORDER_IN)^2 for e blocks in from the edge (1 at the edge and past it)
//              * (1 - smoothstep(0, H, h)) for h blocks above the smoothed ground, H = 8 .. 10 blocks (slow noise)
//              * slow wisps
// so it thickens gradually toward the edge and stops being there at all above 8-10 blocks. borderTau = optical depth
// for one edge along the ray o + d * t, t in 0..L, with e(t) = e0 + de * t. 12 segments, finer near both ends of the
// ray, and the height part integrated exactly in each, so steep rays through the thin bank stay clean. tAt = the
// density-weighted distance of the fog (its colour comes from the biome it sits in).
const float BORDER_IN = 14.0, BORDER_PAST = 14.0, BORDER_RHO = 0.5, BORDER_H = 10.0;
float borderF(float u) { return u <= 0.0 ? u : u >= 1.0 ? 0.5 : u - u * u * u + 0.5 * u * u * u * u; }   // integral of 1 - smoothstep(0, 1, u)
float borderTau(float e0, float de, float L, vec3 o, vec3 d, float time, out float tAt) {
    tAt = 0.0;
    float t0 = 0.0, t1 = L;
    if (abs(de) < 1e-5) { if (e0 >= BORDER_IN || e0 <= -BORDER_PAST) return 0.0; }
    else {
        float ta = (BORDER_IN - e0) / de, tb = (-BORDER_PAST - e0) / de;
        t0 = max(0.0, min(ta, tb));
        t1 = min(L, max(ta, tb));
    }
    if (t1 <= t0) return 0.0;
    float s = 0.0, st = 0.0, near = t0;
    for (int i = 1; i <= 12; i++) {
        float u = float(i) / 12.0;
        float end = t0 + (t1 - t0) * (u - sin(6.2831853 * u) / 6.2831853);
        float tm = 0.5 * (near + end), seg = end - near;
        vec3 m = o + d * tm;
        float inward = clamp(1.0 - (e0 + de * tm) / BORDER_IN, 0.0, 1.0);
        float wisps = fbm(m.xz * 0.06 + WIND * time * 0.12);
        float H = BORDER_H * (0.8 + 0.2 * smoothstep(0.3, 0.7, wisps));
        float ground = 40.0 + bio(m.xz, 1.0).b * 255.0;
        float a0 = (o.y + d.y * near - ground) / H, a1 = (o.y + d.y * end - ground) / H;
        float k = abs(a1 - a0) > 1e-4 ? seg * (borderF(a1) - borderF(a0)) / (a1 - a0)
                                      : seg * (a0 <= 0.0 ? 1.0 : a0 >= 1.0 ? 0.0 : 1.0 - a0 * a0 * (3.0 - 2.0 * a0));
        k *= inward * inward * (0.7 + 0.6 * wisps) * (1.0 - smoothstep(220.0, 320.0, tm));
        s += k;
        st += k * tm;
        near = end;
    }
    tAt = st / max(s, 1e-6);
    return BORDER_RHO * s;
}

// mesa sand wisps: q = (along WIND, across WIND) in blocks. Lanes LANE blocks apart across the wind; each lane is cut
// into cells (10-30 blocks) that slide downwind at the lane's own speed (13-19 blocks/s), and only a few cells carry a
// wisp, so there are always a few here and there. A wisp is 1-24 blocks long (mostly short), at most ~0.2 blocks
// wide in the middle, tapering to points at both ends, and broken up by grain so it reads as dust. Returns 0..1.
float sandLines(vec2 q, float t) {
    const float LANE = 2.2;
    float lane = floor(q.y / LANE), fy = fract(q.y / LANE);
    float x = q.x - t * (13.0 + 6.0 * hash(vec2(lane, 3.1)));
    float seg = 10.0 + 20.0 * hash(vec2(lane, 7.3));
    float cx = floor(x / seg), fx = fract(x / seg);
    if (hash(vec2(lane * 1.7 + 0.3, cx)) > 0.08) return 0.0;           // ~8% of cells have a wisp
    float len = 0.12 + 0.68 * pow(hash(vec2(cx, lane + 9.0)), 1.5);
    float x0 = hash(vec2(cx + 4.0, lane)) * (1.0 - len);
    float u = (fx - x0) / len;                                           // 0..1 along the wisp
    if (u <= 0.0 || u >= 1.0) return 0.0;
    float body = pow(sin(3.14159 * u), 0.8);                             // pointed at both ends
    float halfW = 0.045 * body;                                          // in lanes: <= 0.1 blocks
    float y0 = 0.3 + 0.4 * hash(vec2(cx, lane + 2.0));
    float across = 1.0 - smoothstep(halfW * 0.35, halfW + 0.002, abs(fy - y0));
    float grain = 0.45 + 0.55 * vnoise(vec2(x * 1.6, fy * 30.0 + lane));
    return across * body * grain;
}

// world y of the top face of the terrain at this x/z (the ground itself: trees, rocks and arches stand above it)
float groundTop(vec2 xz) {
    ivec2 b = clamp(ivec2(floor(xz - ORIGIN)), ivec2(0), ivec2(1000));
    return 41.0 + floor(texelFetch(HeightSampler, b, 0).r * 255.0 + 0.5);
}
// the same, blended across block borders (so effects fade over a block at a step instead of cutting off on its edge)
float groundTopSoft(vec2 xz) {
    vec2 p = xz - ORIGIN - 0.5, f = fract(p);
    ivec2 b = ivec2(floor(p));
    float h00 = texelFetch(HeightSampler, clamp(b, ivec2(0), ivec2(1000)), 0).r;
    float h10 = texelFetch(HeightSampler, clamp(b + ivec2(1, 0), ivec2(0), ivec2(1000)), 0).r;
    float h01 = texelFetch(HeightSampler, clamp(b + ivec2(0, 1), ivec2(0), ivec2(1000)), 0).r;
    float h11 = texelFetch(HeightSampler, clamp(b + ivec2(1, 1), ivec2(0), ivec2(1000)), 0).r;
    return 41.0 + 255.0 * mix(mix(h00, h10, f.x), mix(h01, h11, f.x), f.y);
}

// ---- probe cells
float probeRowY;                             // pixel row the cells were found on (-1 = none)
vec3 cell(int i) { return texelFetch(InSampler, ivec2(i, int(probeRowY)), 0).rgb; }   // pixel i of the 16 x 1 strip
float dec(vec3 c, float r) {
    vec3 b = floor(c * 255.0 + 0.5);
    return ((b.r * 65536.0 + b.g * 256.0 + b.b) / 16777215.0 * 2.0 - 1.0) * r;
}
bool isMarker(vec3 c) { return all(lessThan(abs(c * 255.0 - vec3(165.0, 90.0, 195.0)), vec3(0.5))); }

void main() {
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    vec3 wa = bio(cam.xz, 0.0), wb = bio(cam.xz, 1.0);
    float wm = wa.r, wf = wa.g, wv = wa.b, wbl = wb.r;
    float t = GameTime * 1200.0;                                  // seconds of world time
    vec2 px = texCoord * OutSize;

    // probe: cells on the bottom row (GL) or the top row (flipped)
    probeRowY = 0.0;
    bool flipped = false;
    if (!isMarker(cell(15))) { probeRowY = InSize.y - 1.0; flipped = true; }
    bool probe = isMarker(cell(15));
    bool marker = probe;
    mat3 V = mat3(1.0);
    float P00 = 1.0, P11 = 1.0, P22 = 0.0, P32 = 0.05, nightF = 1.0;
    if (probe) {
        for (int c = 0; c < 3; c++) for (int r = 0; r < 3; r++) V[c][r] = dec(cell(c * 3 + r), 1.0001);
        P00 = dec(cell(9), 16.0); P11 = dec(cell(10), 16.0); P22 = dec(cell(11), 8.0); P32 = dec(cell(12), 8.0);
        // how dark it is: DF dims the fog colour in steps at night (rp/df_env.py NIGHT_FOG), so the camera's fog colour
        // against this biome's day fog gives about 1 by day and 0.11 at full night, whatever the player's brightness
        vec3 fogDay = wm * vec3(0.890, 0.761, 0.604) + wf * vec3(0.788, 0.835, 0.886) + wv * vec3(0.239, 0.192, 0.169)
                    + wbl * vec3(0.290, 0.227, 0.353) + wb.g * vec3(0.784, 0.839, 1.0);
        nightF = clamp(luma(cell(14)) / max(luma(fogDay), 0.01), 0.1, 1.0);
        // tolerances widened 2026-11-08 (0.02 / 0.05 -> 0.06 / 0.15): fast movement with view bobbing turned the dot red
        probe = abs(dot(V[0], V[0]) - 1.0) < 0.06 && abs(dot(V[1], V[1]) - 1.0) < 0.06 && abs(dot(V[2], V[2]) - 1.0) < 0.06
             && abs(dot(V[0], V[1])) < 0.06 && abs(determinant(V) - 1.0) < 0.15 && P00 > 0.05 && P11 > 0.05 && P00 < 10.0 && P11 < 10.0;
        // P00 > 0.05 (was 0.2): with a wide window (1920 x 995) and a high FOV, sprint-flying widened the view past
        // ~135 degrees, P00 fell below 0.2, the dot went red and every probe effect switched off (Hobmoves)
    }
    float night = mix(nightF, 1.0, wbl);                         // the corrupted lands' colours are already night-dark

    // hide the probe cells: copy the pixels just past the strip
    vec2 uvIn = texCoord;
    bool inStrip = px.x < 17.0 && (flipped ? px.y > InSize.y - 1.0 : px.y < 1.0);
    if (inStrip) uvIn.y = flipped ? 1.0 - 2.5 / InSize.y : 2.5 / InSize.y;

    float depth = texture(DepthSampler, uvIn).r;
    float lin = depth <= 0.0 ? 1000.0 : min(0.05 / depth, 1000.0);    // view-space depth (reversed, near 0.05)

    // world ray of this pixel
    vec2 ndc = vec2(texCoord.x * 2.0 - 1.0, flipped ? 1.0 - texCoord.y * 2.0 : texCoord.y * 2.0 - 1.0);
    vec3 vdir = vec3(ndc.x / P00, ndc.y / P11, -1.0);
    vec3 wray = transpose(V) * vdir;                             // world offset per unit of view depth
    float L = lin * length(vdir);                                 // distance to the hit (or far for sky)
    vec3 dir = normalize(wray);
    float dist = probe ? min(L, 1000.0) : lin;

    // heat shimmer, mesa: distant pixels wobble a little. Toned down twice on 2026-11-08 ("too wiggly", then "turn
    // down the heat distortion"): 0.55 / 0.35 px (was 1.6 / 1.0, then 0.95 / 0.6), slower than the first version
    vec2 uv = uvIn;
    float shimmer = wm * smoothstep(8.0, 60.0, dist);
    if (shimmer > 0.001) {
        vec2 w = vec2(sin(px.y * 0.11 + t * 4.2 + 2.0 * vnoise(px * 0.02 + t * 0.4)),
                      cos(px.x * 0.05 + t * 3.2 + 2.0 * vnoise(px * 0.03 - t * 0.25)));
        uv += w * shimmer * vec2(0.55, 0.35) / OutSize;
    }
    // heat distortion, crags: air rising off the lava. The lava glow (Hot, already scaled by the crags weight) a bit
    // below this pixel on screen says how much hot air is in front of it; ripples scroll upward. Up to ~1.8 px.
    vec2 below = vec2(0.0, flipped ? 0.035 : -0.035);
    float heat = clamp(luma(texture(HotSampler, texCoord + below).rgb + texture(HotSampler, texCoord).rgb) * 1.6, 0.0, 1.0);
    if (heat > 0.002) {
        float rise = px.y * (flipped ? 0.21 : -0.21) + t * 5.0;
        uv.x += heat * 1.8 * sin(rise + 3.0 * vnoise(px * vec2(0.05, 0.02) + vec2(0.0, t * 0.9))) / OutSize.x;
        uv.y += heat * 0.6 * cos(rise * 0.7 + px.x * 0.13) / OutSize.y;
    }
    vec3 c = texture(InSampler, uv).rgb;

    // lava glow
    vec3 hot = texture(HotSampler, texCoord).rgb;
    c += hot * 1.35 + hot * hot * 0.6;

    // haze: per-biome colour and density by distance, blended by the weights (blight lighter than before)
    float dm = wm * 0.0025, df = wf * (0.009 + 0.010 * smoothstep(110.0, 170.0, cam.y)), dv = wv * 0.009, db = wbl * 0.016;
    float dens = dm + df + dv + db;
    if (dens > 0.0) {
        vec3 fc = (dm * vec3(0.93, 0.80, 0.62) + df * vec3(0.82, 0.88, 0.95) + dv * vec3(0.30, 0.25, 0.22)
                   + db * vec3(0.30, 0.22, 0.38)) / dens;
        float hz = 0.9 * (1.0 - exp(-dist * dens));
        // the sky has its own look (core/sky.fsh) and already meets the fog colour at the horizon: haze veils it fully
        // only low down, and just a little higher up (more in the murky crags and corrupted lands)
        if (depth <= 0.0) hz *= mix(1.0, (dm * 0.12 + df * 0.2 + dv * 0.45 + db * 0.55) / dens, probe ? smoothstep(0.0, 0.2, dir.y) : 1.0);
        c = mix(c, fc * night, hz);
    }

    // ground fog along the ray: 8 segments (finer near the camera and near the hit), each integrated analytically
    // for density D * exp(-(height above the smoothed ground) / H), D / H / colour / noise from the segment middle
    if (probe) {
        float Lm = min(L, 120.0);
        float T = 1.0;
        vec3 acc = vec3(0.0);
        float t0 = 0.0;
        for (int i = 1; i <= 8; i++) {
            float u = float(i) / 8.0;
            float t1 = Lm * (u - sin(6.2831853 * u) / 6.2831853);
            float tm = 0.5 * (t0 + t1), seg = t1 - t0;
            vec3 m = cam + dir * tm;
            vec3 a = bio(m.xz, 0.0), b = bio(m.xz, 1.0);
            float wet = b.g > 0.01 ? bio(m.xz, 2.0).r : 0.0;
            float g = 40.0 + b.b * 255.0;
            // per-biome density at the ground, scale height, colour; noise shapes it into drifting wisps
            float soft = fbm(m.xz * 0.055 + WIND * t * 0.05);
            float streak = 0.0;
            if (a.g > 0.01)
                streak = fbm(vec2(dot(m.xz, WIND) * 0.035 - t * 0.55, dot(m.xz, vec2(-WIND.y, WIND.x)) * 0.32));
            float Db = b.r * 0.22 * (0.25 + 1.6 * soft * soft);
            float Df = b.g * (0.015 + 0.14 * wet) * (0.3 + 1.4 * soft);
            float Dw = a.g * 0.06 * pow(streak, 3.0) * 3.0;
            float Dv = a.b * 0.035 * (0.4 + soft);
            float D = Db + Df + Dw + Dv;
            if (D > 1e-4) {
                float H = (Db * 2.4 + Df * 1.7 + Dw * 1.2 + Dv * 3.2) / D;
                vec3 col = (Db * vec3(0.52, 0.46, 0.58) + Df * vec3(0.80, 0.84, 0.86) + Dw * vec3(0.93, 0.96, 1.0)
                            + Dv * vec3(0.30, 0.26, 0.24)) / D;
                float a0 = max(cam.y + dir.y * t0 - g, 0.0), a1 = max(cam.y + dir.y * t1 - g, 0.0);
                float e0 = exp(-a0 / H), e1 = exp(-a1 / H);
                float I = abs(a1 - a0) > 1e-3 ? seg * H * (e0 - e1) / (a1 - a0) : seg * e0;
                float tau = D * I;
                float k = 1.0 - exp(-tau);
                acc += T * k * col;
                T *= 1.0 - k;
            }
            t0 = t1;
        }
        float k = min(1.0, 0.75 / max(1.0 - T, 1e-4));      // never a wall: 75% opacity at most
        c = c * (1.0 - (1.0 - T) * k) + acc * k * night;
    }

    // mesa: sand streaks racing along the ground near the camera (world-anchored, along WIND). Only on the terrain's
    // own top faces: the normal is turned toward the camera so undersides don't count, and the surface must sit on
    // the exact ground height (groundTop), so tree, rock and arch tops stay clean. Always on, but only a few thin
    // lines here and there (sandLines).
    if (probe && wm > 0.01 && L < 60.0) {
        vec3 wp = cam + dir * L;
        vec3 nrm = normalize(cross(dFdx(wp), dFdy(wp)));
        if (dot(nrm, dir) > 0.0) nrm = -nrm;
        float up = smoothstep(0.65, 0.9, nrm.y);
        float onGround = 1.0 - smoothstep(0.15, 0.45, abs(wp.y - groundTop(wp.xz)));
        vec2 pl = wp.xz - ORIGIN, side = vec2(-WIND.y, WIND.x);
        vec2 q = vec2(dot(pl, WIND), dot(pl, side));
        float dust = sandLines(q, t);
        float dm2 = bio(wp.xz, 0.0).r * up * onGround * (1.0 - smoothstep(22.0, 58.0, L));
        c = mix(c, vec3(0.93, 0.68, 0.44) * night, clamp(dust * 0.35 * dm2, 0.0, 0.35));
    }

    // blight: perlin ground fog (Environment References/01): pixelated patches (1/8 block) of murk with clear ground
    // between them, drifting slowly with the wind. Fog is the haze itself, thicker near the ground, so it takes the
    // blight haze colour (a shade lighter, a bit darker than the ground): it veils the ground and blends into the
    // distance instead of glowing. It settles: thickest in hollows (ground below the smoothed height), thinner on flat
    // ground, little on raised ground; it thins out over the first 0.9 blocks up (groundTopSoft, so it fades across
    // steps instead of cutting off on block edges) and only near the camera (gone by ~70 blocks). The noise n has median
    // ~0.50 and 85th percentile ~0.62 (measured), so patches cover about half the ground. Drawn before the grades.
    // History: eed04aeebe washed everything out; 0f7546b8fc was invisible; 9edf837eff was a lighter tint than the
    // scene (measured 0.39 vs 0.21 ground, 0.16 haze), so it read as a spotlight, not fog.
    if (probe && wbl > 0.01 && L < 70.0) {
        vec3 wp = cam + dir * L;
        float G = groundTopSoft(wp.xz);
        float layer = 1.0 - smoothstep(0.0, 0.9, wp.y - G);
        if (layer > 0.0) {
            float hollow = 41.0 + bio(wp.xz, 1.0).b * 255.0 - G;          // > 0: below the smoothed ground
            float pool = 0.55 + 0.45 * smoothstep(-1.0, 2.5, hollow);
            vec2 pq = floor((wp.xz - ORIGIN) * 4.0) / 4.0;                 // 1/4-block pixels (test; 09886eb6ad had 1/8)
            vec2 drift = WIND * t * 0.35;
            float n = 0.65 * fbm((pq - drift) * 0.13) + 0.35 * fbm((pq - drift * 1.6) * 0.37 + 7.3);
            float patchy = smoothstep(0.44, 0.64, n);
            float graze = 1.0 - abs(dir.y);
            float k = patchy * layer * pool * (0.48 + 0.14 * graze) * bio(wp.xz, 1.0).r * (1.0 - smoothstep(35.0, 70.0, L));
            c = mix(c, vec3(0.33, 0.26, 0.41) * night, k);
        }
    }

    // plot border fog: the wall (BORDER_WALL 1, wallTau) or the low bank (0, borderTau), see BORDER_WALL. Coloured by
    // the biome it sits in. Without the probe: fog by distance once the camera is inside the zone.
    {
        vec2 pc = cam.xz - ORIGIN;                                  // camera in plot coordinates
        float eCam = max(min(min(pc.x, PLOT - pc.x), min(pc.y, PLOT - pc.y)), 0.0);
#if BORDER_WALL
        float amax = 1.0 - smoothstep(24.0, 96.0, eCam);            // full within 24 blocks of an edge, gone from 96
#else
        float amax = 1.0 - smoothstep(60.0, 220.0, eCam);
#endif
        float a = 0.0;
        vec3 bc = borderColor(cam.xz);
        if (amax > 0.0 && probe) {
            float Lb = min(L, 320.0);
            float t1, t2, t3, t4;
#if BORDER_WALL
            float k1 = wallTau(pc.x, dir.x, Lb, cam.y, dir.y, t1), k2 = wallTau(PLOT - pc.x, -dir.x, Lb, cam.y, dir.y, t2);
            float k3 = wallTau(pc.y, dir.z, Lb, cam.y, dir.y, t3), k4 = wallTau(PLOT - pc.y, -dir.z, Lb, cam.y, dir.y, t4);
#else
            float k1 = borderTau(pc.x, dir.x, Lb, cam, dir, t, t1), k2 = borderTau(PLOT - pc.x, -dir.x, Lb, cam, dir, t, t2);
            float k3 = borderTau(pc.y, dir.z, Lb, cam, dir, t, t3), k4 = borderTau(PLOT - pc.y, -dir.z, Lb, cam, dir, t, t4);
#endif
            float tau = k1 + k2 + k3 + k4;
            a = 1.0 - exp(-tau);
            float tAt = (k1 * t1 + k2 * t2 + k3 * t3 + k4 * t4) / max(tau, 1e-6);
            bc = borderColor(cam.xz + dir.xz * tAt);
        } else if (amax > 0.0 && depth > 0.0) {
#if BORDER_WALL
            float bz = clamp(1.0 - eCam / WALL_IN, 0.0, 1.0);
            a = 1.0 - exp(-min(dist, 150.0) * WALL_RHO * bz * bz * bz);
#else
            float bz = clamp(1.0 - eCam / BORDER_IN, 0.0, 1.0);
            float aboveGround = cam.y - (40.0 + bio(cam.xz, 1.0).b * 255.0);
            a = (1.0 - exp(-min(dist, 60.0) * BORDER_RHO * bz * bz)) * (1.0 - smoothstep(0.0, BORDER_H, aboveGround));
#endif
        }
        a *= amax;
#if BORDER_WALL
        a = floor(a * 12.0 + 0.5) / 12.0;                          // flat bands, Minecraft-like, no dither
#endif
        c = mix(c, bc * nightF, a);
    }

    // grades
    float Lu = luma(c);
    c = mix(c, c * vec3(1.07, 1.0, 0.88) + 0.02, wm);                                   // mesa: warm, dusty
    c = mix(c, mix(vec3(Lu), c, 0.75) * vec3(0.92, 0.98, 1.08), wf);                    // frost: cold, less colour
    c = mix(c, pow(max(c, 0.0), vec3(1.12)) * vec3(1.10, 0.98, 0.85), wv);              // crags: warm contrast
    vec3 bl = mix(vec3(Lu), c, 0.68) * vec3(0.97, 0.90, 1.06);                          // blight: drained, purple
    bl = bl * smoothstep(-0.05, 0.75, Lu + 0.1) + vec3(0.02, 0.0, 0.03);
    c = mix(c, bl, wbl * 0.85);

    // wind: world-anchored snow streaks blowing along WIND (frost, stronger up the mountains)
    float wind = wf * (0.35 + 0.65 * smoothstep(105.0, 160.0, cam.y));
    if (probe && wind > 0.01) {
        vec2 side = vec2(-WIND.y, WIND.x);
        float s = 0.0;
        for (int i = 0; i < 6; i++) {
            float d = 1.8 * pow(1.55, float(i));
            if (d > L) break;
            vec3 p = cam + dir * d;
            vec3 qq = vec3(dot(p.xz, WIND) - t * 11.0, dot(p.xz, side) - t * 0.8, p.y + t * 1.2);
            vec3 cl = floor(qq / vec3(2.2, 0.45, 0.45));
            vec3 f = fract(qq / vec3(2.2, 0.45, 0.45));
            if (hash3(cl + float(i) * 17.0) < 0.10) {
                float along = smoothstep(0.0, 0.3, f.x) * smoothstep(1.0, 0.55, f.x);
                float r = length(f.yz - 0.5);
                s += along * (1.0 - smoothstep(0.08, 0.3, r)) * (1.0 - float(i) / 7.0);
            }
            // gust sheets: long soft bands of blown snow flowing along the wind
            float sheet = fbm(vec2(dot(p.xz, WIND) * 0.045 - t * 1.7, dot(p.xz, side) * 0.35 + p.y * 0.4));
            s += smoothstep(0.62, 0.92, sheet) * 0.3 * (1.0 - float(i) / 7.0);
        }
        c = mix(c, vec3(0.95, 0.97, 1.0) * night, clamp(s * 0.7 * wind, 0.0, 0.75));
    }

    // vignettes: frost = pale frosted edge, blight = dark breathing edge, crags = smoky edge
    vec2 e = texCoord - 0.5;
    float r = dot(e, e) * 2.2;
    c = mix(c, vec3(0.88, 0.93, 1.0) * night, wf * 0.3 * smoothstep(0.35, 1.0, r + 0.15 * vnoise(px * 0.03)));
    float breath = 0.75 + 0.25 * sin(t * 0.9);
    c *= 1.0 - wbl * 0.35 * breath * smoothstep(0.25, 1.0, r);
    c *= 1.0 - wv * 0.28 * smoothstep(0.3, 1.0, r);

    // grain (blight and crags)
    float gr = hash(px + fract(t * 13.0) * 100.0) - 0.5;
    if (depth > 0.0) c += gr * (0.03 * wbl + 0.02 * wv);          // the sky stays clean

    // status dot, bottom-right 10 px, ALWAYS drawn while this post effect runs: white = post effect on but no camera
    // data, green = camera data ok, red = probe marker found but bad data. (px.y counts from the bottom; flipped too.)
    float dy = (marker && flipped) ? OutSize.y - 1.0 - px.y : px.y;
    if (px.x > OutSize.x - 16.0 && px.x < OutSize.x - 6.0 && dy > 6.0 && dy < 16.0)
        c = probe ? vec3(0.1, 0.9, 0.2) : (marker ? vec3(0.95, 0.1, 0.1) : vec3(1.0));

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
    gl_FragDepth = depth;
}
