#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

// Gearathon clouds (Hobmoves, 2026-11-08: "more custom/stylized"). Vanilla 26.3 clouds.vsh with our own colouring:
// the cells (shapes from rp/build.py cloud_map, height from DF Cloud_height) are 1.75x thicker and cel-shaded:
// warm bright tops, cool lavender undersides, sides that darken downward, a slight tint per cell so big clouds
// aren't flat, pink-orange at dawn / dusk and moonlit blue at night. The time of day is CloudColor's brightness
// (vanilla multiplies the cloud colour by white .. #191926 over the day, timeline/day.json).

const int FLAG_MASK_DIR = 7;
const int FLAG_INSIDE_FACE = 1 << 4;
const int FLAG_USE_TOP_COLOR = 1 << 5;
const int FLAG_EXTRA_Z = 1 << 6;
const int FLAG_EXTRA_X = 1 << 7;
const float GCLOUD_THICK = 1.75;

layout(std140) uniform CloudInfo {
    vec4 CloudColor;
    vec3 CloudOffset;
    vec3 CellSize;
};

uniform isamplerBuffer CloudFaces;

layout(location = 0) out float vertexDistance;
layout(location = 1) out vec4 vertexColor;

const int packedX = 0xF03CC3;
const int packedY = 0x6666F0;
const int packedZ = 0xC3F066;

vec3 vertex(int index) {
    vec3 pos = vec3(0);
    pos.x = float((packedX >> index) & 1);
    pos.y = float((packedY >> index) & 1);
    pos.z = float((packedZ >> index) & 1);
    return pos;
}

void main() {
    int quadVertex = gl_VertexIndex % 4;
    int index = (gl_VertexIndex / 4) * 3;

    int cellX = texelFetch(CloudFaces, index).r;
    int cellZ = texelFetch(CloudFaces, index + 1).r;
    int dirAndFlags = texelFetch(CloudFaces, index + 2).r;
    int direction = dirAndFlags & FLAG_MASK_DIR;
    bool isInsideFace = (dirAndFlags & FLAG_INSIDE_FACE) == FLAG_INSIDE_FACE;
    bool useTopColor = (dirAndFlags & FLAG_USE_TOP_COLOR) == FLAG_USE_TOP_COLOR;
    cellX = (cellX << 1) | ((dirAndFlags & FLAG_EXTRA_X) >> 7);
    cellZ = (cellZ << 1) | ((dirAndFlags & FLAG_EXTRA_Z) >> 6);
    vec3 faceVertex = vertex((direction * 4) + (isInsideFace ? 3 - quadVertex : quadVertex));
    vec3 scaled = faceVertex * vec3(1.0, GCLOUD_THICK, 1.0);
    vec3 pos = (scaled * CellSize) + (vec3(cellX, 0, cellZ) * CellSize) + CloudOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_spherical_distance(pos);

    float d = clamp(dot(CloudColor.rgb, vec3(0.3333)), 0.0, 1.0);    // 1 day .. ~0.1 night
    float day = smoothstep(0.6, 0.95, d);
    float dusk = smoothstep(0.12, 0.4, d);
    vec3 topC = mix(mix(vec3(0.30, 0.34, 0.55), vec3(1.00, 0.74, 0.60), dusk), vec3(1.00, 0.99, 0.95), day);
    vec3 botC = mix(mix(vec3(0.11, 0.12, 0.24), vec3(0.58, 0.42, 0.62), dusk), vec3(0.66, 0.71, 0.88), day);
    float shade = direction == 1 || useTopColor ? 1.0
                : direction == 0 ? 0.0
                : mix(0.2, 0.85, faceVertex.y) * (direction >= 4 ? 1.0 : 0.93);
    vec3 col = mix(botC, topC, shade);
    float v = fract(sin(dot(vec2(cellX, cellZ), vec2(12.9898, 78.233))) * 43758.5453);
    col *= 0.95 + 0.08 * v;
    vertexColor = vec4(col, min(CloudColor.a * 1.12, 0.95));
}
