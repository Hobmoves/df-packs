#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon HUD (biome bible, "Menus and GUI" > "The HUD"): the hotbar's item counts follow
// their slots to the right edge. The mapping matches core/position_tex_color.vsh; keep them in step.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
// Item counts are white (#FFFFFF, shadow #3F3F3F) and sit in the slot's lower right, y from H - 10 (shadow to H + 0).
// The chat box's typed text shares that row but is #E0E0E0, so the colour keeps it out.
vec2 gearHotbarText(vec2 p, vec3 c) {
    vec3 c8 = c * 255.0;
    bool white = all(greaterThan(c8, vec3(254.5))) || all(lessThan(abs(c8 - vec3(63.0)), vec3(1.5)));
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    float L = floor(sz.x * 0.5) - 91.0, H = sz.y;
    float X = sz.x - 28.0, Y = floor((H - 182.0) * 0.5);
    float u = p.x - L;
    if (!white || p.y < H - 11.5 || p.y > H + 1.5 || u < -29.5 || u > 214.5) return p;
    vec2 toOff = vec2(X - 25.0, Y + 159.0 - (H - 23.0));
    if (u < 0.0) return p + vec2(toOff.x - (L - 29.0), toOff.y);
    if (u > 182.5) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    // a count's glyph quads (8 px wide, shadow 1 px out) span u = 9 + 20 j to 24 + 20 j
    float j = clamp(floor((u - 9.0) / 20.0), 0.0, 8.0);
    return p + vec2(X - L - 20.0 * j, Y + 20.0 * j - (H - 22.0));
}

// The text HUD (biome bible, "The HUD" > "How the text HUD is built"). The plot sends one action bar line (drawn
// centred, its top at y = H - 72) made of groups, each net width 0 so it starts or ends at the screen centre. A group's colour
// is #FE + G + B (its shadow #FD + G + B): g = G / 4 names the element, b = B / 4 its index. Each group is moved from
// that origin to its place (GUI px from the screen edges, the mock-up rp/src/gui/hud_preview.py), scaled, and given
// its real colour. Must match rp/hud_df.py (the g codes) and rp/hud.py (glyph sizes).
const vec3 GEAR_PAL[8] = vec3[8](vec3(255.0), vec3(150.0, 146.0, 160.0), vec3(243.0, 230.0, 196.0),
    vec3(217.0, 160.0, 50.0), vec3(244.0, 215.0, 122.0), vec3(111.0, 207.0, 90.0), vec3(168.0, 104.0, 28.0), vec3(255.0));
// 0 white, 1 dim, 2 cream, 3 gold, 4 pale gold, 5 green, 6 dark gold, 7 art (untinted, no shadow)

bool gearHud(inout vec2 p, inout vec4 col, vec2 sz) {
    vec3 c8 = floor(col.rgb * 255.0 + 0.5);
    bool sh = c8.r == 253.0;
    if (c8.r != 254.0 && !sh) return false;
    int g = int(c8.g) / 4, b = int(c8.b) / 4;
    float W = sz.x, H = sz.y, SM = 2.0 / 3.0, s = 1.0, a = 1.0;
    int k = 7;
    float my = b == 0 ? 65.0 : 95.0;                                   // teammate card b's top
    int qm = b / 16;                                                   // quest: teammates shown, row
    float Q = qm == 0 ? 69.0 : (qm == 1 ? 100.0 : 130.0), qy = Q + 25.0 + 11.0 * float(b % 16);
    float ex = W - 28.0 - 28.0 * float(b);                             // effect badge b
    int fl = b / 8;                                                    // pickup line (0 = newest), fade step b % 8
    float fy = H - 14.0 - 25.0 / 3.0 * float(fl);
    vec2 A;
    switch (g) {
        case 1: A = vec2(44, 8); break;                               // card plate
        case 2: A = vec2(6, 6); break;                                // big head frame
        case 3: A = vec2(11, 11); s = 4.0; break;                     // head
        case 4: A = vec2(52, 12); k = 0; break;                       // name
        case 5: A = vec2(152, 12); k = 0; break;                      // health (right-aligned)
        case 6: A = vec2(152, 12); k = 1; break;                      // " | max"
        case 7: A = vec2(52, 22); break;                              // health bar
        case 8: A = vec2(52, 33); break;                              // mana bar
        case 9: A = vec2(152, 39); s = SM; k = 0; break;              // mana (right-aligned, small)
        case 10: A = vec2(152, 39); s = SM; k = 1; break;
        case 11: A = vec2(52, 46); k = 2; break;                      // biome
        case 12: A = vec2(52.0 + float(b), 48.0); s = SM; k = 3; break;   // ": room", b = the biome's width
        case 13: A = vec2(28.0, my + 1.0); break;                     // teammate b: plate
        case 14: A = vec2(10.0, my); break;                           // frame
        case 15: A = vec2(14.0, my + 4.0); s = 2.0; break;            // head
        case 16: A = vec2(37.0, my + 3.0); s = SM; k = 0; break;      // name
        case 17: A = vec2(37.0, my + 10.0); break;                    // bar
        case 18: A = vec2(37.0, my + 17.0); s = SM; k = 2; break;     // biome
        case 19: A = vec2(37.0 + SM * float(b), 65.0 + 17.0 - SM); s = SM; k = 3; break;  // teammate 0 ": room"
        case 20: A = vec2(37.0 + SM * float(b), 95.0 + 17.0 - SM); s = SM; k = 3; break;  // teammate 1
        case 21: A = vec2(6.0, Q); break;                             // quest plate
        case 22: A = vec2(10.0, Q + 3.0); k = 1; break;               // "No current quest active."
        case 23: A = vec2(10.0, Q + 3.0); s = SM; k = 6; break;       // "QUEST"
        case 24: A = vec2(33.0, Q + 6.0); break;                      // rule
        case 25: A = vec2(10.0, Q + 12.0); k = 4; break;              // quest name
        case 26: A = vec2(11.0, qy); break;                           // task checkbox
        case 28: A = vec2(22.0, qy); k = 0; break;                    // task
        case 29: A = vec2(22.0, qy); k = 1; break;                    // task done
        case 30: A = vec2(159.0, qy); k = 3; break;                   // count (right-aligned)
        case 31: A = vec2(159.0, qy); k = 5; break;                   // count done
        case 32: A = vec2(ex, 6.0); break;                            // effect badge
        case 33: A = vec2(ex + 2.0, 8.0); break;                      // its icon
        case 34: A = vec2(ex + 17.0, 19.0 + SM); s = SM; k = 0; break;    // level (right-aligned)
        case 35: A = vec2(ex + 1.0, 30.0); break;                     // timer pill
        case 36: case 37: case 38:                                    // pickup line (right-aligned at the edge)
            A = vec2(W - 6.0, fy); s = fl == 0 ? 1.0 : SM;
            k = g == 36 ? 7 : (g == 37 ? 3 : 0);
            a = (fl == 0 ? 1.0 : 0.84 - 0.18 * float(fl - 1)) * float(b % 8) / 7.0;
            break;
        default: return false;
    }
    p = A + (p - vec2(floor(W * 0.5), H - 72.0)) * s;
    if (sh && k == 7) p = vec2(-1.0e4);
    col = vec4(GEAR_PAL[k] / (sh ? 4.0 * 255.0 : 255.0), a);
    return true;
}
#endif

void main() {
    vec4 col = Color;
#ifdef IS_GUI
    vec4 p = ModelViewMat * vec4(Position, 1.0);
    if (ProjMat[2][3] == 0.0) {
        vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
        if (!gearHud(p.xy, col, sz)) p.xy = gearHotbarText(p.xy, Color.rgb);
    }
    gl_Position = ProjMat * p;
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = col;
#endif
    texCoord0 = UV0;
}
