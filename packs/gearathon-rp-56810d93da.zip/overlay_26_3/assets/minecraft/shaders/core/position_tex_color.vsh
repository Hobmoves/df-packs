#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon HUD's hotbar move (biome bible, "Menus and GUI" > "The HUD"): the game still
// draws its own hotbar at the bottom centre, and this stands it up along the right edge. The same mapping is in
// core/text.vsh (item counts) and core/gui.vsh (durability and cooldown bars), and rp/hud.py mirrors it in Python
// for the preview. Keep the four in step.
//
// No #include here: vanilla notes this program is used during startup, before resource packs exist.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;

bool gearNear(float a, float b) { return abs(a - b) < 0.05; }

// Vanilla's hotbar in GUI pixels: hotbar sprite 182 x 22 at (L, H - 22); selection 24 x 23 at (L - 1 + 20 s, H - 23);
// slot j's item 16 x 16 at (L + 3 + 20 j, H - 19); off-hand sprite 29 x 24 at (L - 29, H - 23) (left) or (L + 182,
// H - 23) (right), its item 3 px in. L = floor(width / 2) - 91.
// Ours: the strip 22 wide x 182 tall at (X, Y), X = width - 28, Y centred; the hotbar's u axis runs down it.
vec2 gearHotbar(vec2 p) {
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    float L = floor(sz.x * 0.5) - 91.0, H = sz.y;
    float X = sz.x - 28.0, Y = floor((H - 182.0) * 0.5);
    float u = p.x - L, v = p.y - (H - 22.0);
    // hotbar and selection sprites: turned 90 degrees, top edge to the right (keeps the winding)
    float m = mod(u + 1.0, 20.0);
    bool bar = (gearNear(u, 0.0) || gearNear(u, 182.0)) && (gearNear(p.y, H - 22.0) || gearNear(p.y, H));
    bool sel = (gearNear(m, 0.0) || gearNear(m, 20.0) || gearNear(m, 4.0)) && u > -1.5 && u < 183.5
               && (gearNear(p.y, H - 23.0) || gearNear(p.y, H));
    if (bar || sel) return vec2(X + 22.0 - v, Y + u);
    // off-hand sprites, moved left of the last slot
    bool offRow = gearNear(p.y, H - 23.0) || gearNear(p.y, H + 1.0);
    vec2 toOff = vec2(X - 25.0, Y + 159.0 - (H - 23.0));
    if (offRow && (gearNear(u, -29.0) || gearNear(u, 0.0))) return p + vec2(toOff.x - (L - 29.0), toOff.y);
    if (offRow && (gearNear(u, 182.0) || gearNear(u, 211.0))) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    // item icons: moved into their cell, not turned
    if (gearNear(p.y, H - 19.0) || gearNear(p.y, H - 3.0)) {
        float k = mod(u - 3.0, 20.0);
        if ((gearNear(k, 0.0) || gearNear(k, 20.0) || gearNear(k, 16.0)) && u > 0.0 && u < 182.0) {
            float j = floor(u / 20.0);
            return p + vec2(X - L - 20.0 * j, Y + 20.0 * j - (H - 22.0));
        }
        if (gearNear(u, -26.0) || gearNear(u, -10.0)) return p + vec2(toOff.x - (L - 29.0), toOff.y);
        if (gearNear(u, 192.0) || gearNear(u, 208.0)) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    }
    return p;
}

void main() {
    vec4 p = ModelViewMat * vec4(Position, 1.0);
    if (ProjMat[2][3] == 0.0) {                        // orthographic: the GUI
        p.xy = gearHotbar(p.xy);
    }
    gl_Position = ProjMat * p;

    texCoord0 = UV0;
    vertexColor = Color;
}
