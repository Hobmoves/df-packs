#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
layout(location = 7) flat out float probeOn;
layout(location = 8) flat out vec3 probeCol;

// Gearathon probe (see assets/gearathon/models/item/probe.json): an item display of minecraft:structure_block whose
// 16 face pairs carry constant tints (253, 16*i+7 or +9, 89). Each face is moved to data cell i (bottom-left corner, 1/512 of the
// screen per cell, nearest depth) and writes value i: the camera rotation, projection terms, the sky light colour,
// the fog colour and a marker. post/biome reads the cells to rebuild world positions (ground fog, wind) and hides them.
vec3 gearEnc(float v, float r) {
    float u = clamp(v / r * 0.5 + 0.5, 0.0, 1.0);
    int n = int(u * 16777215.0 + 0.5);
    return vec3(float((n >> 16) & 255), float((n >> 8) & 255), float(n & 255)) / 255.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;

    probeOn = 0.0;
    probeCol = vec3(0.0);
    vec3 pc = floor(Color.rgb * 255.0 + 0.5);
    float lo = mod(pc.g, 16.0);                   // 7 = front face, 9 = the back face (opposite winding)
    if (pc.r == 253.0 && pc.b == 89.0 && (lo == 7.0 || lo == 9.0)) {
        int i = int(pc.g) / 16;
        int k = gl_VertexIndex % 4;
        bool rev = lo == 9.0;
        vec2 corner = vec2((rev ? (k == 0 || k == 3) : (k == 1 || k == 2)) ? 1.0 : 0.0, k >= 2 ? 1.0 : 0.0);
        vec2 ndc = -1.0 + (vec2(float(i), 0.0) + corner) * (2.0 / 512.0);
        vec4 np = ProjMat * vec4(0.0, 0.0, -0.08, 1.0);
        gl_Position = vec4(ndc, np.z / np.w, 1.0);
        probeOn = 1.0;
        if (i < 9) probeCol = gearEnc(ModelViewMat[i / 3][i % 3], 1.0001);
        else if (i == 9) probeCol = gearEnc(ProjMat[0][0], 16.0);
        else if (i == 10) probeCol = gearEnc(ProjMat[1][1], 16.0);
        else if (i == 11) probeCol = gearEnc(ProjMat[2][2], 8.0);
        else if (i == 12) probeCol = gearEnc(ProjMat[3][2], 8.0);
    #ifndef OIT_ALPHA_ONLY
        else if (i == 13) probeCol = texture(Sampler2, vec2(0.5 / 16.0, 15.5 / 16.0)).rgb;
    #endif
        else if (i == 14) probeCol = FogColor.rgb;
        else if (i == 15) probeCol = vec3(165.0, 90.0, 195.0) / 255.0;
    }
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
