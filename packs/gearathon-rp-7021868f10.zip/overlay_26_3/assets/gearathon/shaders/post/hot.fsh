#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Bloom source for the volcanic crags: only lava-coloured bright pixels, scaled by how volcanic the camera's spot is.
// The two box_blur passes after this spread it into a glow; post/biome adds it back.

uniform sampler2D InSampler;
uniform sampler2D BiomesSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec2 ORIGIN = vec2(0.0, 8000.0);   // world x/z of plot block (0, 0)
const float PLOT = 1001.0;

void main() {
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    vec2 p = clamp((cam.xz - ORIGIN + 0.5) / PLOT, 0.002, 0.998);
    float wv = texture(BiomesSampler, vec2(p.x * 0.5, p.y)).b;
    vec3 c = texture(InSampler, texCoord).rgb;
    float hot = smoothstep(0.6, 0.95, c.r) * smoothstep(0.15, 0.45, c.r - c.b) * step(c.b, c.g + 0.08);
    fragColor = vec4(c * hot * wv, 1.0);
}
