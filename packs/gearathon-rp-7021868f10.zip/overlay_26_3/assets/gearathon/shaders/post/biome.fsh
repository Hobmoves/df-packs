#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Gearathon biome look, one post effect for the whole plot (DF: player_action.SetPostEffects gearathon:biome).
// The camera's world position (Globals.CameraBlockPos - CameraOffset) picks blended biome weights from
// textures/effect/biomes.png (left half R mesa, G frost, B volcanic; right half R blight, G forest), so crossing a
// border fades smoothly with no server help. Distance comes from main's reversed depth (~0.05 / depth, sky = 0).
//   mesa      light heat shimmer on distant things, warm dusty grade
//   frost     cold grade, pale fog, blowing snow streaks (stronger up high), frosted vignette
//   volcanic  smoky brown fog, warm contrast, lava glow (bloom from post/hot)
//   blight    heavy purple fog, desaturated, crushed shadows, slow breathing vignette, grain
// Fog colours are also set per biome by DF (ColorEnvOption), this adds the look on top.

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D HotSampler;
uniform sampler2D BiomesSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec2 ORIGIN = vec2(0.0, 8000.0);   // world x/z of plot block (0, 0)
const float PLOT = 1001.0;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

// blowing snow: short bright dashes on a sheared grid scrolling with the wind
float snow(vec2 px, float t, float k) {
    vec2 q = px / vec2(90.0 + 40.0 * k, 9.0 + 4.0 * k);
    q.x += t * (5.0 + 3.0 * k) + q.y * 0.35;
    q.y += t * (0.6 + 0.3 * k);
    vec2 cell = floor(q), f = fract(q);
    float h = hash(cell + 17.0 * k);
    if (h > 0.22) return 0.0;
    float y0 = 0.25 + 0.5 * hash(cell + 3.1);
    float len = 0.25 + 0.5 * hash(cell + 7.7);
    float x0 = hash(cell + 9.3) * (1.0 - len);
    float dx = smoothstep(x0, x0 + 0.05, f.x) * smoothstep(x0 + len, x0 + len - 0.15, f.x);
    float dy = 1.0 - smoothstep(0.0, 0.09, abs(f.y - y0));
    return dx * dy;
}

void main() {
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    vec2 p = clamp((cam.xz - ORIGIN + 0.5) / PLOT, 0.002, 0.998);
    vec3 wa = texture(BiomesSampler, vec2(p.x * 0.5, p.y)).rgb;
    vec3 wb = texture(BiomesSampler, vec2(0.5 + p.x * 0.5, p.y)).rgb;
    float wm = wa.r, wf = wa.g, wv = wa.b, wbl = wb.r;
    float t = GameTime * 1200.0;                                  // seconds of world time

    float depth = texture(DepthSampler, texCoord).r;
    float dist = depth <= 0.0 ? 1000.0 : min(0.05 / depth, 1000.0);
    vec2 px = texCoord * OutSize;

    // heat shimmer: distant pixels wobble a little (mesa strong, crags weak)
    vec2 uv = texCoord;
    float shimmer = (wm + 0.35 * wv) * smoothstep(8.0, 60.0, dist);
    if (shimmer > 0.001) {
        vec2 w = vec2(sin(px.y * 0.11 + t * 7.0 + 2.0 * vnoise(px * 0.02 + t * 0.6)),
                      cos(px.x * 0.05 + t * 5.3 + 2.0 * vnoise(px * 0.03 - t * 0.4)));
        uv += w * shimmer * vec2(1.6, 1.0) / OutSize;
    }
    vec3 c = texture(InSampler, uv).rgb;

    // lava glow
    vec3 hot = texture(HotSampler, texCoord).rgb;
    c += hot * 1.35 + hot * hot * 0.6;

    // fog: per-biome colour and density, blended by the weights
    float dm = wm * 0.0025, df = wf * (0.011 + 0.012 * smoothstep(110.0, 170.0, cam.y)), dv = wv * 0.010, db = wbl * 0.024;
    float dens = dm + df + dv + db;
    if (dens > 0.0) {
        vec3 fc = (dm * vec3(0.93, 0.80, 0.62) + df * vec3(0.82, 0.88, 0.95) + dv * vec3(0.27, 0.22, 0.19)
                   + db * vec3(0.17, 0.10, 0.23)) / dens;
        float amb = 0.0;                                          // scene brightness, so the fog darkens at night
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
            amb += luma(texture(InSampler, vec2(0.2 + 0.3 * float(i), 0.2 + 0.3 * float(j))).rgb);
        fc *= clamp(amb / 9.0 * 2.2, 0.25, 1.0);
        c = mix(c, fc, 0.92 * (1.0 - exp(-dist * dens)));
    }

    // grades
    float L = luma(c);
    c = mix(c, c * vec3(1.07, 1.0, 0.88) + 0.02, wm);                                  // mesa: warm, dusty
    c = mix(c, mix(vec3(L), c, 0.75) * vec3(0.92, 0.98, 1.08), wf);                    // frost: cold, less colour
    c = mix(c, pow(max(c, 0.0), vec3(1.12)) * vec3(1.10, 0.98, 0.85), wv);              // crags: warm contrast
    vec3 bl = mix(vec3(L), c, 0.55) * vec3(0.95, 0.85, 1.08);                           // blight: drained, purple
    bl = bl * smoothstep(0.0, 0.85, L + 0.08) + vec3(0.025, 0.0, 0.04);
    c = mix(c, bl, wbl);

    // blowing snow, stronger up the mountains
    float wind = wf * (0.3 + 0.7 * smoothstep(105.0, 160.0, cam.y));
    if (wind > 0.001) {
        float s = snow(px, t, 0.0) + 0.7 * snow(px + 300.0, t, 1.0) + 0.5 * snow(px + 700.0, t, 2.0);
        c = mix(c, vec3(0.95, 0.97, 1.0), clamp(s * 0.55 * wind, 0.0, 0.8));
        c = mix(c, vec3(0.86, 0.9, 0.96), 0.10 * wind * vnoise(px * 0.004 + vec2(t * 0.8, 0.0)));
    }

    // vignettes: frost = pale frosted edge, blight = dark breathing edge, crags = smoky edge
    vec2 e = texCoord - 0.5;
    float r = dot(e, e) * 2.2;
    c = mix(c, vec3(0.88, 0.93, 1.0), wf * 0.35 * smoothstep(0.35, 1.0, r + 0.15 * vnoise(px * 0.03)));
    float breath = 0.75 + 0.25 * sin(t * 0.9);
    c *= 1.0 - wbl * 0.65 * breath * smoothstep(0.2, 1.0, r);
    c *= 1.0 - wv * 0.30 * smoothstep(0.3, 1.0, r);

    // grain (blight and crags)
    float g = hash(px + fract(t * 13.0) * 100.0) - 0.5;
    c += g * (0.045 * wbl + 0.02 * wv);

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
    gl_FragDepth = depth;
}
