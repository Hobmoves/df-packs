#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Gearathon biome look, one post effect for the whole plot (DF: player_action.SetPostEffects gearathon:biome).
// The camera's world position (Globals.CameraBlockPos - CameraOffset) picks blended biome weights from
// textures/effect/biomes.png (3 blocks of 256x256, rows = plot z, cols = plot x):
//   block 0: R mesa, G frost, B volcanic    block 1: R blight, G forest, B smoothed ground height (y - 40)
//   block 2: R wetness (near ponds)
// The probe (core/item.vsh, an item display DF keeps on each player) writes the camera rotation, projection, sky
// light and a marker into 16 cells in the bottom-left corner of main; with them every pixel gets its world position:
//   ground fog  analytic height fog per ray segment, hugging the smoothed ground, drifting with the wind:
//               blight heavy purple-grey, forest mist over ponds / wet hollows, frost blowing snow drift,
//               mesa running dust (+ sand streaks racing over the ground), crags low smoke
//   wind        world-anchored snow streaks and gust sheets (frost) blowing along WIND, so they stay put when you turn
//   night       fog and haze follow the sky light (no screen-brightness guess, so no flicker)
// Without probe data (e.g. third person) the ground fog / streaks are skipped and the rest still works.
//   mesa      light heat shimmer on distant things, warm dusty grade
//   frost     cold grade, pale haze, frosted vignette
//   volcanic  smoky brown haze, warm contrast, lava glow (bloom from post/hot)
//   blight    purple haze, desaturated, breathing vignette, grain (lighter than v1)

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
uniform sampler2D HotSampler;
uniform sampler2D BiomesSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec2 ORIGIN = vec2(0.0, 8000.0);   // world x/z of plot block (0, 0)
const float PLOT = 1001.0;
const vec2 WIND = vec2(-0.932, 0.362);    // blowing toward -x, +z (same as the DF snow particles)
const float CELLS = 512.0;               // probe cell = 1/512 of the screen

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float hash3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }

float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

float fbm(vec2 p) { return 0.62 * vnoise(p) + 0.38 * vnoise(p * 2.3 + 5.2); }

// screen-space blowing snow (fallback when there is no probe data)
float snowS(vec2 px, float t, float k) {
    vec2 q = px / vec2(90.0 + 40.0 * k, 9.0 + 4.0 * k);
    q.x += t * (5.0 + 3.0 * k) + q.y * 0.35;
    q.y += t * (0.6 + 0.3 * k);
    vec2 cl = floor(q), f = fract(q);
    if (hash(cl + 17.0 * k) > 0.22) return 0.0;
    float y0 = 0.25 + 0.5 * hash(cl + 3.1), len = 0.25 + 0.5 * hash(cl + 7.7), x0 = hash(cl + 9.3) * (1.0 - len);
    return smoothstep(x0, x0 + 0.05, f.x) * smoothstep(x0 + len, x0 + len - 0.15, f.x) * (1.0 - smoothstep(0.0, 0.09, abs(f.y - y0)));
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec2 plotUV(vec2 xz) { return clamp((xz - ORIGIN + 0.5) / PLOT, 0.5 / 256.0, 1.0 - 0.5 / 256.0); }
vec3 bio(vec2 xz, float block) { vec2 p = plotUV(xz); return texture(BiomesSampler, vec2((block + p.x) / 3.0, p.y)).rgb; }

// ---- probe cells
float probeRowY;                             // pixel row the cells were found on (-1 = none)
vec3 cell(int i) { return texelFetch(InSampler, ivec2(int((float(i) + 0.5) * InSize.x / CELLS), int(probeRowY)), 0).rgb; }
float dec(vec3 c, float r) {
    vec3 b = floor(c * 255.0 + 0.5);
    return ((b.r * 65536.0 + b.g * 256.0 + b.b) / 16777215.0 * 2.0 - 1.0) * r;
}
bool isMarker(vec3 c) { return all(lessThan(abs(c * 255.0 - vec3(165.0, 90.0, 195.0)), vec3(0.5))); }

void main() {
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    vec3 wa = bio(cam.xz, 0.0), wb = bio(cam.xz, 1.0);
    float wm = wa.r, wf = wa.g, wv = wa.b, wbl = wb.r;
    float t = GameTime * 1200.0;                                  // seconds of world time
    vec2 px = texCoord * OutSize;

    // probe: cells on the bottom row (GL) or the top row (flipped)
    float ch = InSize.y / CELLS;
    probeRowY = floor(0.5 * ch);
    bool flipped = false;
    if (!isMarker(cell(15))) { probeRowY = InSize.y - 1.0 - floor(0.5 * ch); flipped = true; }
    bool probe = isMarker(cell(15));
    bool marker = probe;
    mat3 V = mat3(1.0);
    float P00 = 1.0, P11 = 1.0, P22 = 0.0, P32 = 0.05, day = 1.0;
    if (probe) {
        for (int c = 0; c < 3; c++) for (int r = 0; r < 3; r++) V[c][r] = dec(cell(c * 3 + r), 1.0001);
        P00 = dec(cell(9), 16.0); P11 = dec(cell(10), 16.0); P22 = dec(cell(11), 8.0); P32 = dec(cell(12), 8.0);
        day = clamp(luma(cell(13)) * 1.15, 0.0, 1.0);
        probe = abs(dot(V[0], V[0]) - 1.0) < 0.02 && abs(dot(V[1], V[1]) - 1.0) < 0.02 && abs(dot(V[2], V[2]) - 1.0) < 0.02
             && abs(dot(V[0], V[1])) < 0.02 && abs(determinant(V) - 1.0) < 0.05 && P00 > 0.2 && P11 > 0.2 && P00 < 10.0 && P11 < 10.0;
    }
    float night = mix(0.4, 1.0, smoothstep(0.08, 0.75, day));

    // hide the probe cells: copy the pixels just past the strip
    vec2 uvIn = texCoord;
    bool inStrip = px.x < 16.0 * InSize.x / CELLS + 1.0 && (flipped ? px.y > InSize.y - ch - 1.0 : px.y < ch + 1.0);
    if (inStrip) uvIn.y = flipped ? 1.0 - (ch + 2.0) / InSize.y : (ch + 2.0) / InSize.y;

    float depth = texture(DepthSampler, uvIn).r;
    float lin = depth <= 0.0 ? 1000.0 : min(0.05 / depth, 1000.0);    // view-space depth (reversed, near 0.05)

    // world ray of this pixel
    vec2 ndc = vec2(texCoord.x * 2.0 - 1.0, flipped ? 1.0 - texCoord.y * 2.0 : texCoord.y * 2.0 - 1.0);
    vec3 vdir = vec3(ndc.x / P00, ndc.y / P11, -1.0);
    vec3 wray = transpose(V) * vdir;                             // world offset per unit of view depth
    float L = lin * length(vdir);                                 // distance to the hit (or far for sky)
    vec3 dir = normalize(wray);
    float dist = probe ? min(L, 1000.0) : lin;

    // heat shimmer: distant pixels wobble a little (mesa strong, crags weak)
    vec2 uv = uvIn;
    float shimmer = (wm + 0.35 * wv) * smoothstep(8.0, 60.0, dist);
    if (shimmer > 0.001) {
        vec2 w = vec2(sin(px.y * 0.11 + t * 7.0 + 2.0 * vnoise(px * 0.02 + t * 0.6)),
                      cos(px.x * 0.05 + t * 5.3 + 2.0 * vnoise(px * 0.03 - t * 0.4)));
        uv += w * shimmer * vec2(1.6, 1.0) / OutSize;
    }
    vec3 c = texture(InSampler, uv).rgb;

    // lava glow
    vec3 hot = texture(HotSampler, texCoord).rgb;
    c += hot * 1.35 + hot * hot * 0.6;

    // haze: per-biome colour and density by distance, blended by the weights (blight lighter than before)
    float dm = wm * 0.0025, df = wf * (0.009 + 0.010 * smoothstep(110.0, 170.0, cam.y)), dv = wv * 0.009, db = wbl * 0.016;
    float dens = dm + df + dv + db;
    if (dens > 0.0) {
        vec3 fc = (dm * vec3(0.93, 0.80, 0.62) + df * vec3(0.82, 0.88, 0.95) + dv * vec3(0.30, 0.25, 0.22)
                   + db * vec3(0.30, 0.22, 0.38)) / dens;
        c = mix(c, fc * night, 0.9 * (1.0 - exp(-dist * dens)));
    }

    // ground fog along the ray: 8 segments (finer near the camera and near the hit), each integrated analytically
    // for density D * exp(-(height above the smoothed ground) / H), D / H / colour / noise from the segment middle
    if (probe) {
        float Lm = min(L, 120.0);
        float T = 1.0;
        vec3 acc = vec3(0.0);
        float t0 = 0.0;
        for (int i = 1; i <= 8; i++) {
            float u = float(i) / 8.0;
            float t1 = Lm * (u - sin(6.2831853 * u) / 6.2831853);
            float tm = 0.5 * (t0 + t1), seg = t1 - t0;
            vec3 m = cam + dir * tm;
            vec3 a = bio(m.xz, 0.0), b = bio(m.xz, 1.0);
            float wet = b.g > 0.01 ? bio(m.xz, 2.0).r : 0.0;
            float g = 40.0 + b.b * 255.0;
            // per-biome density at the ground, scale height, colour; noise shapes it into drifting wisps
            float soft = fbm(m.xz * 0.055 + WIND * t * 0.05);
            float streak = 0.0;
            if (a.r + a.g > 0.01)
                streak = fbm(vec2(dot(m.xz, WIND) * 0.035 - t * 0.55, dot(m.xz, vec2(-WIND.y, WIND.x)) * 0.32));
            float Db = b.r * 0.22 * (0.25 + 1.6 * soft * soft);
            float Df = b.g * (0.015 + 0.14 * wet) * (0.3 + 1.4 * soft);
            float Dw = a.g * 0.06 * pow(streak, 3.0) * 3.0;
            float Dm = a.r * 0.05 * pow(streak, 3.0) * 3.2;
            float Dv = a.b * 0.035 * (0.4 + soft);
            float D = Db + Df + Dw + Dm + Dv;
            if (D > 1e-4) {
                float H = (Db * 2.4 + Df * 1.7 + Dw * 1.2 + Dm * 1.4 + Dv * 3.2) / D;
                vec3 col = (Db * vec3(0.52, 0.46, 0.58) + Df * vec3(0.80, 0.84, 0.86) + Dw * vec3(0.93, 0.96, 1.0)
                            + Dm * vec3(0.86, 0.68, 0.48) + Dv * vec3(0.30, 0.26, 0.24)) / D;
                float a0 = max(cam.y + dir.y * t0 - g, 0.0), a1 = max(cam.y + dir.y * t1 - g, 0.0);
                float e0 = exp(-a0 / H), e1 = exp(-a1 / H);
                float I = abs(a1 - a0) > 1e-3 ? seg * H * (e0 - e1) / (a1 - a0) : seg * e0;
                float tau = D * I;
                float k = 1.0 - exp(-tau);
                acc += T * k * col;
                T *= 1.0 - k;
            }
            t0 = t1;
        }
        float k = min(1.0, 0.75 / max(1.0 - T, 1e-4));      // never a wall: 75% opacity at most
        c = c * (1.0 - (1.0 - T) * k) + acc * k * night;
    }

    // mesa: sand streaks racing along the ground on upward faces near the camera (world-anchored, along WIND)
    if (probe && wm > 0.01 && L < 60.0) {
        vec3 wp = cam + dir * L;
        vec3 nrm = normalize(cross(dFdx(wp), dFdy(wp)));
        float up = smoothstep(0.65, 0.9, abs(nrm.y));
        vec2 pl = wp.xz - ORIGIN, side = vec2(-WIND.y, WIND.x);
        vec2 q = vec2(dot(pl, WIND), dot(pl, side));
        float s1 = fbm(vec2(q.x * 0.11 - t * 2.4, q.y * 0.85));
        float s2 = fbm(vec2(q.x * 0.32 - t * 3.6, q.y * 2.1 + 3.0));
        float gust = smoothstep(0.35, 0.75, fbm(q * 0.018 - vec2(t * 0.25, 0.0)));
        float dust = smoothstep(0.52, 0.86, 0.7 * s1 + 0.4 * s2) * (0.35 + 0.65 * gust);
        float dm2 = bio(wp.xz, 0.0).r * up * (1.0 - smoothstep(22.0, 58.0, L));
        c = mix(c, vec3(0.88, 0.74, 0.55) * night, clamp(dust * 0.55 * dm2, 0.0, 0.6));
    }

    // grades
    float Lu = luma(c);
    c = mix(c, c * vec3(1.07, 1.0, 0.88) + 0.02, wm);                                   // mesa: warm, dusty
    c = mix(c, mix(vec3(Lu), c, 0.75) * vec3(0.92, 0.98, 1.08), wf);                    // frost: cold, less colour
    c = mix(c, pow(max(c, 0.0), vec3(1.12)) * vec3(1.10, 0.98, 0.85), wv);              // crags: warm contrast
    vec3 bl = mix(vec3(Lu), c, 0.68) * vec3(0.97, 0.90, 1.06);                          // blight: drained, purple
    bl = bl * smoothstep(-0.05, 0.75, Lu + 0.1) + vec3(0.02, 0.0, 0.03);
    c = mix(c, bl, wbl * 0.85);

    // wind: world-anchored snow streaks blowing along WIND (frost, stronger up the mountains)
    float wind = wf * (0.35 + 0.65 * smoothstep(105.0, 160.0, cam.y));
    if (probe && wind > 0.01) {
        vec2 side = vec2(-WIND.y, WIND.x);
        float s = 0.0;
        for (int i = 0; i < 6; i++) {
            float d = 1.8 * pow(1.55, float(i));
            if (d > L) break;
            vec3 p = cam + dir * d;
            vec3 qq = vec3(dot(p.xz, WIND) - t * 11.0, dot(p.xz, side) - t * 0.8, p.y + t * 1.2);
            vec3 cl = floor(qq / vec3(2.2, 0.45, 0.45));
            vec3 f = fract(qq / vec3(2.2, 0.45, 0.45));
            if (hash3(cl + float(i) * 17.0) < 0.10) {
                float along = smoothstep(0.0, 0.3, f.x) * smoothstep(1.0, 0.55, f.x);
                float r = length(f.yz - 0.5);
                s += along * (1.0 - smoothstep(0.08, 0.3, r)) * (1.0 - float(i) / 7.0);
            }
            // gust sheets: long soft bands of blown snow flowing along the wind
            float sheet = fbm(vec2(dot(p.xz, WIND) * 0.045 - t * 1.7, dot(p.xz, side) * 0.35 + p.y * 0.4));
            s += smoothstep(0.62, 0.92, sheet) * 0.3 * (1.0 - float(i) / 7.0);
        }
        c = mix(c, vec3(0.95, 0.97, 1.0) * night, clamp(s * 0.7 * wind, 0.0, 0.75));
    }

    // vignettes: frost = pale frosted edge, blight = dark breathing edge, crags = smoky edge
    vec2 e = texCoord - 0.5;
    float r = dot(e, e) * 2.2;
    c = mix(c, vec3(0.88, 0.93, 1.0) * night, wf * 0.3 * smoothstep(0.35, 1.0, r + 0.15 * vnoise(px * 0.03)));
    float breath = 0.75 + 0.25 * sin(t * 0.9);
    c *= 1.0 - wbl * 0.35 * breath * smoothstep(0.25, 1.0, r);
    c *= 1.0 - wv * 0.28 * smoothstep(0.3, 1.0, r);

    // grain (blight and crags)
    float gr = hash(px + fract(t * 13.0) * 100.0) - 0.5;
    c += gr * (0.03 * wbl + 0.02 * wv);

    // probe status dot, top-right 6 px: green = camera data ok, red = marker but bad data, none = no marker
    if (px.x > OutSize.x - 7.0 && px.y > OutSize.y - 7.0 && marker) c = probe ? vec3(0.1, 0.9, 0.2) : vec3(0.9, 0.1, 0.1);

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
    gl_FragDepth = depth;
}
