#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>

// Gearathon sky (Hobmoves, 2026-11-08). Replaces vanilla's flat sky colour with a pixel-art skybox painted per WORLD
// direction. It's a cube around the camera at infinity, so it stays fixed in the world, turns with your view and
// never follows you. Each face is a GRID x GRID pixel grid, like vanilla's square stars.
//   day factor  d = ColorModulator.b. Vanilla multiplies the sky colour by white (day) .. black (night)
//               (timeline/day.json), and DF sends #78A7FF everywhere (rp/df_env.py SKY), so blue = d.
//   biome look  FogColor (DF's per-biome fog) at the horizon, so the sky meets the distance fog without a seam;
//               thick-fog biomes (fog end < ~150) still bury the sky in fog like vanilla.
//   day         deep blue zenith -> pale horizon (the clouds are vanilla's 3D ones)
//   twilight    violet zenith, pink band, orange horizon (vanilla's sunrise fan adds the glow on the sun's side)
//   night       navy -> indigo, a faint band of pixel stars (vanilla's turning stars draw on top) and, now and
//               then, a shooting star (GameTime)
// Sun, moon, stars and the sunrise fan are vanilla's own passes, drawn after this one.

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

const float GSKY_GRID = 256.0;                 // pixels per cube face (~0.45 degrees each)

float gskyHash(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }

float gskyNoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = gskyHash(vec3(i, 0.0)), b = gskyHash(vec3(i + vec2(1, 0), 0.0));
    float c = gskyHash(vec3(i + vec2(0, 1), 0.0)), e = gskyHash(vec3(i + vec2(1, 1), 0.0));
    return mix(mix(a, b, f.x), mix(c, e, f.x), f.y);
}

void main() {
    vec3 dir = normalize(skyPos);

    // snap the direction to the centre of its pixel on the cube; id names the pixel
    vec3 ad = abs(dir);
    float m = max(ad.x, max(ad.y, ad.z));
    vec3 onCube = dir / m;
    vec3 id = floor(onCube * GSKY_GRID * 0.5);
    vec3 q = (id + 0.5) / (GSKY_GRID * 0.5);
    if (ad.x == m) { q.x = sign(dir.x); id.x = sign(dir.x) * 999.0; }
    else if (ad.y == m) { q.y = sign(dir.y); id.y = sign(dir.y) * 999.0; }
    else { q.z = sign(dir.z); id.z = sign(dir.z) * 999.0; }
    vec3 p = normalize(q);

    float t = GameTime * 1200.0;                                        // seconds
    float d = clamp(ColorModulator.b, 0.0, 1.0);
    float day = smoothstep(0.55, 0.95, d);
    float dusk = smoothstep(0.02, 0.35, d);                             // 0 night .. 1 twilight and day
    float night = 1.0 - dusk;

    // gradient in 20 flat bands, blended with a 2 x 2 ordered dither: pixel steps like a retro sky, not a smooth fade
    vec2 bay = mod(id.xz + id.y, 2.0);
    float up = clamp(p.y, 0.0, 1.0);
    float z = clamp(floor(pow(up, 0.55) * 20.0 + (bay.x * 2.0 + bay.y) * 0.25) / 20.0, 0.0, 1.0);   // 0 horizon .. 1 zenith
    vec3 dayC = mix(vec3(0.70, 0.85, 1.00), vec3(0.22, 0.45, 0.93), z);
    vec3 twC = mix(vec3(1.00, 0.58, 0.32), vec3(0.93, 0.45, 0.58), smoothstep(0.0, 0.2, up));
    twC = mix(twC, vec3(0.24, 0.20, 0.52), smoothstep(0.15, 0.75, up));
    vec3 niC = mix(vec3(0.07, 0.08, 0.20), vec3(0.012, 0.018, 0.06), z);
    vec3 c = mix(mix(niC, twC, dusk), dayC, day);

    // clouds: not painted here (flat clouds at infinity didn't move past you, Hobmoves 2026-11-08). Vanilla's 3D
    // clouds are back with our shapes (rp/build.py cloud_map), raised above the mountains by DF (Cloud_height).

    // night: a faint band of stars across the sky, plus a few shooting stars
    if (night > 0.001 && p.y > -0.05) {
        vec3 axis = normalize(vec3(0.35, 0.55, 0.76));
        float band = exp(-pow(dot(p, axis) / 0.22, 2.0));
        c += vec3(0.10, 0.07, 0.16) * band * (0.5 + 0.5 * gskyNoise(p.xz * 9.0 + p.y * 5.0)) * night;
        float h = gskyHash(id);
        float star = step(1.0 - (0.006 + 0.03 * band), h) * (0.35 + 0.65 * fract(h * 37.0));
        star *= 0.75 + 0.25 * sin(t * 2.3 + h * 60.0);
        c += vec3(0.85, 0.88, 1.0) * star * night * smoothstep(-0.05, 0.15, p.y);

        float slot = floor(t / 6.0), ph = t - slot * 6.0;              // a meteor in ~40% of 6 s slots, 0.9 s long
        if (gskyHash(vec3(slot, 1.7, 3.1)) < 0.4 && ph < 0.9) {
            vec3 s0 = normalize(vec3(gskyHash(vec3(slot, 2, 0)) * 2.0 - 1.0, 0.3 + 0.5 * gskyHash(vec3(slot, 3, 0)),
                                     gskyHash(vec3(slot, 4, 0)) * 2.0 - 1.0));
            vec3 along = normalize(cross(s0, normalize(vec3(gskyHash(vec3(slot, 5, 0)) - 0.5, 1.5, gskyHash(vec3(slot, 6, 0)) - 0.5))));
            float k = ph / 0.9;
            vec3 head = normalize(s0 + along * k * 0.55);
            vec3 tail = normalize(s0 + along * max(k - 0.3, 0.0) * 0.55);
            vec3 ab = head - tail;
            float s = clamp(dot(p - tail, ab) / max(dot(ab, ab), 1e-6), 0.0, 1.0);
            float dist = length(p - (tail + ab * s));
            float px = 2.2 / GSKY_GRID;
            float line = (1.0 - smoothstep(px * 0.5, px, dist)) * s * sin(k * 3.14159);
            c += vec3(1.0, 0.95, 0.85) * line * night;
        }
    }

    // below the horizon: the fog colour, like vanilla
    c = mix(FogColor.rgb, c, smoothstep(-0.02, 0.02, dir.y));

    // fog: vanilla's sky fog (0 .. FogSkyEnd along the ray to the disc), lightened for clear skies so the gradient
    // and sunsets show, kept in full for thick-fog biomes
    float fv = linear_fog_value(length(skyPos), 0.0, FogSkyEnd);
    float thick = 1.0 - smoothstep(110.0, 200.0, FogSkyEnd);
    fv = mix(pow(fv, 2.2) * 0.85, fv, thick);
    fragColor = vec4(mix(c, FogColor.rgb, fv * FogColor.a), ColorModulator.a);
}
