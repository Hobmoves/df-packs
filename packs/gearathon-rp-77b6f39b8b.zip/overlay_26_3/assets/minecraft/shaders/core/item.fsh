#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
layout(location = 7) flat in float probeOn;
layout(location = 8) flat in vec3 probeCol;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

// value in [-r, r] as 24-bit fixed point RGB (post/biome.fsh dec() is the inverse)
vec3 gearEnc(float v, float r) {
    float q = floor(clamp(v / r * 0.5 + 0.5, 0.0, 1.0) * 16777215.0 + 0.5);
    float hi = floor(q / 65536.0); q -= hi * 65536.0;
    float mid = floor(q / 256.0); q -= mid * 256.0;
    return vec3(hi, mid, q) / 255.0;
}

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    #ifndef OIT_ALPHA_ONLY
    if (probeOn > 0.5) {                      // Gearathon probe strip (see item.vsh): pixel i holds value i, exact
        int i = int(gl_FragCoord.x);
        vec3 v = vec3(0.0);
        if (i < 9) v = gearEnc(ModelViewMat[i / 3][i % 3], 1.0001);
        else if (i == 9) v = gearEnc(ProjMat[0][0], 16.0);
        else if (i == 10) v = gearEnc(ProjMat[1][1], 16.0);
        else if (i == 11) v = gearEnc(ProjMat[2][2], 8.0);
        else if (i == 12) v = gearEnc(ProjMat[3][2], 8.0);
        else if (i == 13) v = probeCol;
        else if (i == 14) v = FogColor.rgb;
        else v = vec3(165.0, 90.0, 195.0) / 255.0;
        fragColor = vec4(v, 1.0);
        return;
    }
    #endif
    vec4 color = texture(Sampler0, texCoord0);
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
